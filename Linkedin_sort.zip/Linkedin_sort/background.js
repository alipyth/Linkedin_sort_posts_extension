chrome.runtime.onInstalled.addListener(() => {
    console.log("LinkedIn Post Sorter installed!");
});
