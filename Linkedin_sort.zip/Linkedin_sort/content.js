// Selectors for posts and specific metrics
const POST_SELECTOR = ".feed-shared-update-v2__control-menu-container";
const LIKE_SELECTOR = ".social-details-social-counts__social-proof-fallback-number";
const REPOST_SELECTOR = ".social-details-social-counts__item--truncate-text";

// Extract numeric value from the target element
const extractCount = (element) => {
    if (!element) return 0;
    const text = element.innerText || "0";
    return parseInt(text.replace(/[^\d]/g, ""), 10) || 0;
};

// Sort posts based on a given criterion
function sortPosts(criteriaSelector) {
    const posts = Array.from(document.querySelectorAll(POST_SELECTOR));

    posts.sort((a, b) => {
        const countA = extractCount(a.querySelector(criteriaSelector));
        const countB = extractCount(b.querySelector(criteriaSelector));
        return countB - countA; // Descending order
    });

    // Reattach posts in sorted order
    const parent = document.querySelector(POST_SELECTOR).parentElement;
    posts.forEach(post => parent.appendChild(post));
}

// Add UI buttons for sorting
function addSortingButtons() {
    const controlPanel = document.querySelector(".scaffold-finite-scroll");
    if (!controlPanel || document.querySelector(".custom-sort-buttons")) return;

    const sortDiv = document.createElement("div");
    sortDiv.className = "custom-sort-buttons";
    sortDiv.style.margin = "10px";

    const likeButton = document.createElement("button");
    likeButton.innerText = "Sort by Likes";
    likeButton.style.marginRight = "10px";
    likeButton.style.fontWeight = "bold"; // Makes text bold
    likeButton.style.padding = "8px 12px"; // Adds padding
    likeButton.style.border = "2px solid #0a66c2"; // LinkedIn blue border
    likeButton.style.borderRadius = "5px"; // Rounded corners
    likeButton.style.backgroundColor = "#f3f2ef"; // Light background color
    likeButton.style.cursor = "pointer"; // Pointer on hover
    likeButton.onmouseover = () => (likeButton.style.backgroundColor = "#e6e6e6"); // Hover effect
    likeButton.onmouseleave = () => (likeButton.style.backgroundColor = "#f3f2ef");
    likeButton.onclick = () => sortPosts(LIKE_SELECTOR);

    const repostButton = document.createElement("button");
    repostButton.innerText = "Sort by Reposts";
    repostButton.style.fontWeight = "bold"; // Makes text bold
    repostButton.style.padding = "8px 12px"; // Adds padding
    repostButton.style.border = "2px solid #0a66c2"; // LinkedIn blue border
    repostButton.style.borderRadius = "5px"; // Rounded corners
    repostButton.style.backgroundColor = "#f3f2ef"; // Light background color
    repostButton.style.cursor = "pointer"; // Pointer on hover
    repostButton.onmouseover = () => (repostButton.style.backgroundColor = "#e6e6e6"); // Hover effect
    repostButton.onmouseleave = () => (repostButton.style.backgroundColor = "#f3f2ef");
    repostButton.onclick = () => sortPosts(REPOST_SELECTOR);

    sortDiv.appendChild(likeButton);
    sortDiv.appendChild(repostButton);
    controlPanel.prepend(sortDiv);
}

// Observe LinkedIn's dynamic content and add buttons
const observer = new MutationObserver(() => addSortingButtons());
observer.observe(document.body, { childList: true, subtree: true });

// Message listener for external requests (popup or background.js)
chrome.runtime.onMessage.addListener((request) => {
    if (request.action === "sortByLikes") {
        sortPosts(LIKE_SELECTOR);
    } else if (request.action === "sortByReposts") {
        sortPosts(REPOST_SELECTOR);
    }
});
